//Autores: TIANXIANG WANG Y HAOXUAN XU
//GRUPO: G20

#ifndef inputOutput_h
#define inputOutput_h

#include "Sudoku.h"

void mostrar_juego_consola(const tSudoku& s);
int menu();
#endif
